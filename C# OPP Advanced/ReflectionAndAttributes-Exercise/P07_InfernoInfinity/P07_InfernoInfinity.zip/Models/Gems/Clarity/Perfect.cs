﻿using System;
using System.Collections.Generic;
using System.Text;


public class Perfect : Clarity
{
    private const int increasesDmg = 5;

    public Perfect()
        : base(increasesDmg)
    {
    }
}

