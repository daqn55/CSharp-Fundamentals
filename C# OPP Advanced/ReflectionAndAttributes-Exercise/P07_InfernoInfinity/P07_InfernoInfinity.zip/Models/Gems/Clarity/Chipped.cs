﻿using System;
using System.Collections.Generic;
using System.Text;


public class Chipped : Clarity
{
    private const int increasesDmg = 1;

    public Chipped()
        : base(increasesDmg)
    {
    }
}

