﻿using System;
using System.Collections.Generic;
using System.Text;


public class Regular : Clarity
{
    private const int increasesDmg = 2;

    public Regular()
        : base(increasesDmg)
    {
    }
}

