﻿using System;
using System.Collections.Generic;
using System.Text;


public class Flawless : Clarity
{
    private const int increasesDmg = 10;

    public Flawless()
        : base(increasesDmg)
    {
    }
}

