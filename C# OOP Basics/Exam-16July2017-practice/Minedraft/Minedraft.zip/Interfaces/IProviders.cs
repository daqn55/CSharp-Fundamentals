﻿using System;
using System.Collections.Generic;
using System.Text;


public interface IProviders
{
    string Id { get; }
    double EnergyOutput { get; }
}

