﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Model
{
    public class Backpack : Bag
    {
        public Backpack() : base(100)
        {
        }
    }
}
