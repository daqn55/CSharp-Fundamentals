﻿using System.Collections.Generic;

namespace DungeonsAndCodeWizards.Model
{
    public enum Faction
    {
        CSharp,
        Java
    }
}